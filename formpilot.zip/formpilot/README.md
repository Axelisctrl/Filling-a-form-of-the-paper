# FormPilot

Upload a form (PDF, Word, JPG, PNG), save your details once, autofill, review every answer, download a filled PDF or an answer sheet.

## What works today
| Feature | Free mode (no key) | AI mode (`ANTHROPIC_API_KEY` set) |
|---|---|---|
| Accounts, profile, dashboard, delete data | yes | yes |
| PDF text, Word text, image OCR | yes | yes |
| Fillable PDFs (real form fields) filled in place | yes | yes |
| Field detection in flat PDFs, Word, images | simple pattern rules | AI reads the layout |
| Plain-language explanations of questions | no | yes |
| Profile autofill | keyword matching (name, email, address...) | AI matching |
| Drafts for essay questions | no | yes (marked "AI draft") |
| Download | filled PDF, or answer-sheet PDF | same |

Not built yet (be honest with users about this): OCR of scanned PDFs (upload them as images instead), filling Word files in place (you get an answer sheet), flat PDFs filled in place, encryption of files at rest, email verification and password reset, multiple languages in OCR (English only).

## Run on your computer
1. Install Node.js 18+ from nodejs.org.
2. In this folder: `npm install`
3. Copy `.env.example` to `.env`. Set `JWT_SECRET` to a long random string. Leave `ANTHROPIC_API_KEY` empty for free mode.
4. `npm start`, then open http://localhost:3000

## Put it on GitHub
1. Create a free account at github.com and click New repository (name it `formpilot`, keep it Private).
2. In this folder run:
```
git init
git add .
git commit -m "FormPilot first version"
git branch -M main
git remote add origin https://github.com/YOUR-NAME/formpilot.git
git push -u origin main
```
`.gitignore` already keeps `.env`, `node_modules` and `data` out of GitHub. Never upload your `.env`.

## Deploy (Render example)
1. Sign up at render.com, click New, then Web Service, and connect your GitHub repo.
2. Build command `npm install`, start command `npm start`.
3. Environment variables: `NODE_ENV=production`, `JWT_SECRET=<long random>`, and optionally `ANTHROPIC_API_KEY`.
4. Important: user files and accounts are saved in the `data/` folder. Free hosting disks are wiped on restart, so add a persistent disk mounted at `/opt/render/project/src/data` (a paid feature) before real users sign up.
5. Use the HTTPS address Render gives you. Cookies are marked secure in production.

## Costs (check current prices before enabling)
- Free mode: only hosting. Local use costs nothing. Public hosting with a persistent disk is normally a few dollars per month; check your host's pricing page.
- AI mode: the AI provider charges per amount of text processed, so cost grows with form length and number of users. Set a spending limit in the provider console before turning it on, and test with a few forms first. Each upload makes 1 AI call and each autofill makes 1 more.

## Security notes
- API key lives only in server environment variables; the browser never sees it.
- Passwords are hashed (bcrypt); sessions use an httpOnly, SameSite=strict cookie; login is rate limited.
- Every document route checks that the file belongs to the signed-in user. Uploaded files get random names and a 15 MB limit and type filter.
- Deleting a document or account removes the stored file and records.
- When AI mode is on, the form text and the user's profile are sent to the AI provider. Tell your users, and review the provider's data terms. Do not claim any compliance certification (GDPR, HIPAA, SOC 2) unless you have actually obtained it.
- Before launch: add disk encryption, backups, email verification, a privacy policy, and move `data/db.json` to a real database.

## Files
`server.js` API and security, `lib/analyze.js` extraction, field detection, autofill, `lib/export.js` PDF output, `lib/store.js` storage, `public/` website.
