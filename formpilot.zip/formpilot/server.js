require('dotenv').config();
const express = require('express'), helmet = require('helmet'), rate = require('express-rate-limit'),
  cookie = require('cookie-parser'), multer = require('multer'), bcrypt = require('bcryptjs'),
  jwt = require('jsonwebtoken'), fs = require('fs'), path = require('path'), crypto = require('crypto');
const db = require('./lib/store'), { extractText, detectFields, autofill, aiOn } = require('./lib/analyze'), { exportPdf } = require('./lib/export');

const SECRET = process.env.JWT_SECRET;
if (!SECRET || SECRET.length < 24) { console.error('Set JWT_SECRET (24+ characters) in your environment.'); process.exit(1); }
const PROD = process.env.NODE_ENV === 'production';
const UP = path.join(__dirname, 'data', 'uploads');
fs.mkdirSync(UP, { recursive: true });
const KEYS = ['fullName', 'dob', 'nationality', 'email', 'phone', 'address', 'city', 'postal', 'country', 'passportNo', 'education', 'employment', 'skills', 'about'];
const TYPES = { 'application/pdf': 1, 'application/vnd.openxmlformats-officedocument.wordprocessingml.document': 1, 'image/png': 1, 'image/jpeg': 1 };

const app = express();
app.set('trust proxy', 1);
app.use(helmet({ contentSecurityPolicy: { directives: { defaultSrc: ["'self'"], scriptSrc: ["'self'"], styleSrc: ["'self'", 'https://fonts.googleapis.com'], fontSrc: ['https://fonts.gstatic.com'], imgSrc: ["'self'", 'data:'], upgradeInsecureRequests: null } } }));
app.use(express.json({ limit: '200kb' }), cookie());
app.use('/api/', rate({ windowMs: 15 * 60e3, max: 400 }));
const authLimit = rate({ windowMs: 15 * 60e3, max: 20, message: { error: 'Too many attempts. Try again in a few minutes.' } });

const auth = (req, res, next) => {
  try { const t = jwt.verify(req.cookies.fp, SECRET); req.user = db.d.users.find(u => u.id === t.id); if (!req.user) throw 0; next(); }
  catch (e) { res.status(401).json({ error: 'Please sign in.' }); }
};
const own = (req, res) => {
  const x = db.d.docs.find(d => d.id === req.params.id && d.userId === req.user.id);
  if (!x) res.status(404).json({ error: 'Document not found.' }); return x;
};
const pub = d => ({ id: d.id, name: d.name, status: d.status, aiUsed: d.aiUsed, mime: d.mime, fields: d.fields, createdAt: d.createdAt });
const setCookie = (res, u) => res.cookie('fp', jwt.sign({ id: u.id }, SECRET, { expiresIn: '7d' }), { httpOnly: true, sameSite: 'strict', secure: PROD, maxAge: 7 * 864e5 });
const wipe = d => { try { fs.unlinkSync(d.file); } catch (e) { /* already gone */ } };

app.get('/api/status', (req, res) => res.json({ ai: aiOn() }));
app.post('/api/register', authLimit, async (req, res) => {
  const { email, password } = req.body || {};
  if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email || '') || email.length > 120) return res.status(400).json({ error: 'Enter a valid email address.' });
  if (typeof password !== 'string' || password.length < 10 || password.length > 100) return res.status(400).json({ error: 'Password must be 10 to 100 characters.' });
  if (db.d.users.some(u => u.email === email.toLowerCase())) return res.status(400).json({ error: 'That email already has an account.' });
  const u = { id: crypto.randomUUID(), email: email.toLowerCase(), hash: await bcrypt.hash(password, 12), profile: {} };
  db.d.users.push(u); db.save(); setCookie(res, u); res.json({ email: u.email });
});
app.post('/api/login', authLimit, async (req, res) => {
  const { email, password } = req.body || {};
  const u = db.d.users.find(x => x.email === String(email || '').toLowerCase());
  if (!u || !(await bcrypt.compare(String(password || ''), u.hash))) return res.status(400).json({ error: 'Email or password is incorrect.' });
  setCookie(res, u); res.json({ email: u.email });
});
app.post('/api/logout', (req, res) => { res.clearCookie('fp'); res.json({ ok: true }); });
app.get('/api/me', auth, (req, res) => res.json({ email: req.user.email }));
app.delete('/api/me', auth, (req, res) => {
  db.d.docs.filter(d => d.userId === req.user.id).forEach(wipe);
  db.d.docs = db.d.docs.filter(d => d.userId !== req.user.id);
  db.d.users = db.d.users.filter(u => u.id !== req.user.id);
  db.save(); res.clearCookie('fp'); res.json({ ok: true });
});
app.get('/api/profile', auth, (req, res) => res.json(req.user.profile));
app.put('/api/profile', auth, (req, res) => {
  const p = {};
  KEYS.forEach(k => { const v = (req.body || {})[k]; if (typeof v === 'string' && v.trim()) p[k] = v.trim().slice(0, 2000); });
  req.user.profile = p; db.save(); res.json(p);
});

const storage = multer.diskStorage({ destination: UP, filename: (r, f, cb) => cb(null, crypto.randomBytes(16).toString('hex')) });
const upload = multer({ storage, limits: { fileSize: 15 * 1024 * 1024 }, fileFilter: (r, f, cb) => TYPES[f.mimetype] ? cb(null, true) : cb(new Error('Unsupported file type. Use PDF, DOCX, JPG or PNG.')) }).single('file');

app.post('/api/docs', auth, (req, res, next) => upload(req, res, e => e ? res.status(400).json({ error: e.code === 'LIMIT_FILE_SIZE' ? 'File is larger than 15 MB.' : e.message }) : next()), async (req, res) => {
  if (!req.file) return res.status(400).json({ error: 'Choose a file to upload.' });
  try {
    const { text, acro } = await extractText(req.file.path, req.file.mimetype);
    const { fields, aiUsed } = await detectFields(text, acro);
    if (!fields.length) throw new Error('No questions or fields were found. Try a clearer file' + (aiOn() ? '.' : ', or turn on the AI provider for harder forms.'));
    const d = { id: crypto.randomUUID(), userId: req.user.id, name: path.basename(req.file.originalname).slice(0, 120), file: req.file.path, mime: req.file.mimetype, fields, aiUsed, status: 'draft', createdAt: new Date().toISOString() };
    db.d.docs.push(d); db.save(); res.json(pub(d));
  } catch (e) { try { fs.unlinkSync(req.file.path); } catch (x) { /* ignore */ } res.status(422).json({ error: e.message }); }
});
app.get('/api/docs', auth, (req, res) => res.json(db.d.docs.filter(d => d.userId === req.user.id).map(d => ({ id: d.id, name: d.name, status: d.status, createdAt: d.createdAt, total: d.fields.length, missing: d.fields.filter(f => !f.answer).length })).reverse()));
app.get('/api/docs/:id', auth, (req, res) => { const d = own(req, res); if (d) res.json(pub(d)); });
app.put('/api/docs/:id', auth, (req, res) => {
  const d = own(req, res); if (!d) return;
  (Array.isArray(req.body.fields) ? req.body.fields : []).forEach(x => {
    const f = d.fields.find(y => y.id === x.id); if (!f || typeof x.answer !== 'string') return;
    const a = x.answer.slice(0, 5000);
    if (a !== f.answer) { f.answer = a; f.source = 'user'; f.status = a.trim() ? 'edited' : 'missing'; }
  });
  db.save(); res.json(pub(d));
});
app.post('/api/docs/:id/autofill', auth, async (req, res) => {
  const d = own(req, res); if (!d) return;
  try {
    const r = await autofill(d.fields.filter(f => f.status !== 'edited'), req.user.profile);
    d.fields.forEach(f => { if (r[f.id]) Object.assign(f, r[f.id]); });
    db.save(); res.json(pub(d));
  } catch (e) { res.status(502).json({ error: e.message }); }
});
app.post('/api/docs/:id/export', auth, async (req, res) => {
  const d = own(req, res); if (!d) return;
  if (req.body.confirmed !== true) return res.status(400).json({ error: 'Confirm that you reviewed every answer first.' });
  try {
    const { buf, filled } = await exportPdf(d);
    d.status = 'completed'; db.save();
    res.set({ 'content-type': 'application/pdf', 'x-filled-original': filled ? '1' : '0', 'cache-control': 'no-store' }).send(buf);
  } catch (e) { res.status(500).json({ error: 'Could not create the PDF: ' + e.message }); }
});
app.delete('/api/docs/:id', auth, (req, res) => {
  const d = own(req, res); if (!d) return;
  wipe(d); db.d.docs = db.d.docs.filter(x => x.id !== d.id); db.save(); res.json({ ok: true });
});

app.use(express.static(path.join(__dirname, 'public')));
app.use((e, req, res, next) => { console.error(e.message); res.status(500).json({ error: 'Unexpected server error.' }); });
app.listen(process.env.PORT || 3000, () => console.log('FormPilot running. AI provider: ' + (aiOn() ? 'on' : 'off (free mode)')));
