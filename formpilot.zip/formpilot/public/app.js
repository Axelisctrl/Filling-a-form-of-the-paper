(() => {
const PF = [['fullName','Full legal name'],['dob','Date of birth'],['nationality','Nationality'],['email','Email'],['phone','Phone'],['address','Street address'],['city','City'],['postal','Postal code'],['country','Country'],['passportNo','Passport number (optional)'],['education','Education history'],['employment','Employment history'],['skills','Skills and languages'],['about','About you (used for essay-style drafts)']];
const LONG = ['education','employment','skills','about','address'];
const $ = s => document.querySelector(s), root = $('#root');
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
let user = null, ai = false, busy = false;

async function api(p, o = {}) {
  const fd = o.body instanceof FormData;
  const r = await fetch('/api' + p, { method: o.method || 'GET', credentials: 'same-origin', headers: o.body && !fd ? { 'content-type': 'application/json' } : {}, body: o.body && !fd ? JSON.stringify(o.body) : o.body });
  if (r.ok && (r.headers.get('content-type') || '').includes('pdf')) return r;
  const j = await r.json().catch(() => ({}));
  if (!r.ok) { if (r.status === 401 && user) { user = null; go('#/login'); } throw new Error(j.error || 'Something went wrong.'); }
  return j;
}
let tt; const toast = m => { const t = $('#toast'); t.textContent = m; t.className = 'on'; clearTimeout(tt); tt = setTimeout(() => t.className = '', 3800); };
const go = h => { location.hash = h; };
const logo = '<a class="logo" href="#/"><i><svg viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><path d="M4 12l16-8-6 16-3-7z"/></svg></i>FormPilot</a>';
const head = on => `<header class="top"><div class="w">${logo}<nav class="m">${user ? `<a class="l ${on==='d'?'on':''}" href="#/dashboard">Dashboard</a><a class="l ${on==='p'?'on':''}" href="#/profile">Profile</a><button class="btn sec" data-act="logout">Sign out</button>` : `<a class="l" href="#/login">Sign in</a><a class="btn" href="#/login?new">Get started</a>`}</nav></div></header>`;

function landing() {
  root.innerHTML = head() + `<main><section class="hero"><div class="w"><h1>Every Form. Less Manual Work.</h1>
<p>Upload your paperwork, let AI understand it, and prepare your answers in minutes. FormPilot helps you complete forms with less repetition and greater clarity.</p>
<a class="btn lg" href="#/login?new">Create a free account</a><div class="note">Works for school, work, government, visa, tax and insurance forms. You always review before you download.</div></div></section>
<section class="s"><div class="w"><h2>How it works</h2><div class="grid4">
<div><b>1</b><h3>Upload</h3><p>Add a PDF, Word document or photo of your form.</p></div>
<div><b>2</b><h3>Understand</h3><p>FormPilot finds each question and field. With the AI provider on, it also explains them in plain language.</p></div>
<div><b>3</b><h3>Autofill</h3><p>Your saved profile fills what it can. Anything it does not know is marked missing, never guessed.</p></div>
<div><b>4</b><h3>Review and download</h3><p>Edit every answer, then download the filled PDF or an answer sheet.</p></div></div></div></section>
<section class="s soft"><div class="w"><h2>Paperwork it can help with</h2><div class="tags"><span>School and university</span><span>Scholarships</span><span>Employment</span><span>Government paperwork</span><span>Passport documents</span><span>Visa and immigration</span><span>Business registration</span><span>Tax forms</span><span>Insurance</span></div><p style="margin-top:22px;max-width:44em">Results depend on the quality of the file. Scanned forms are read with OCR, which can make mistakes. Complex layouts may need manual fixes, so always check the output.</p></div></section>
<section class="s"><div class="w"><h2>Your information stays yours</h2><div class="grid3">
<div><h3>Private by default</h3><p>Files are stored under your account only and cannot be opened by other users.</p></div>
<div><h3>Delete any time</h3><p>Deleting a document removes the file and its answers. Deleting your account removes everything.</p></div>
<div><h3>Honest about AI</h3><p>When the optional AI provider is on, form text and your profile are sent to it to produce answers. In free mode nothing leaves this server.</p></div></div></div></section></main>
<footer><div class="w">FormPilot prepares answers; it is not legal, tax or immigration advice. Review everything before you submit.</div></footer>`;
}

function authView(isNew) {
  root.innerHTML = head() + `<main class="w"><form class="auth card" data-form="auth" data-new="${isNew ? 1 : 0}"><h1 style="font-size:28px;margin-bottom:18px">${isNew ? 'Create your account' : 'Welcome back'}</h1>
<label for="em">Email</label><input id="em" type="email" autocomplete="email" required><div style="height:12px"></div>
<label for="pw">Password ${isNew ? '(at least 10 characters)' : ''}</label><input id="pw" type="password" autocomplete="${isNew ? 'new-password' : 'current-password'}" required minlength="${isNew ? 10 : 1}"><div class="err" id="err"></div>
<button class="btn">${isNew ? 'Create account' : 'Sign in'}</button><p style="text-align:center;font-size:14px">${isNew ? 'Already registered? <a href="#/login">Sign in</a>' : 'New here? <a href="#/login?new">Create an account</a>'}</p></form></main>`;
}

async function dashboard() {
  root.innerHTML = head('d') + '<main class="w page"><p><span class="spin"></span>Loading…</p></main>';
  const [docs, prof] = await Promise.all([api('/docs'), api('/profile')]);
  const filled = Object.keys(prof).length;
  root.innerHTML = head('d') + `<main class="w page"><h1>Your forms</h1><p class="sub">${ai ? 'AI provider is on: forms are explained and essay answers can be drafted.' : 'Free mode: fields are found with simple rules and filled from your profile. No AI provider is connected.'}</p>
${filled < 3 ? '<div class="warn">Your profile is mostly empty. <a href="#/profile">Add your details</a> so FormPilot has facts to use.</div>' : ''}
<div class="drop" id="drop" tabindex="0" role="button"><b>Upload a form</b>PDF, Word (.docx), JPG or PNG, up to 15 MB. Click or drop a file here.<input id="file" type="file" accept=".pdf,.docx,.png,.jpg,.jpeg" hidden></div>
<div class="card"><h3 style="margin-bottom:6px">Documents</h3>${docs.length ? docs.map(d => `<div class="row"><div><div class="n">${esc(d.name)}</div><small>${new Date(d.createdAt).toLocaleDateString()} · ${d.total - d.missing} of ${d.total} answered</small></div><div class="acts"><span class="chip ${d.status}">${d.status === 'completed' ? 'Completed' : 'Draft'}</span><a class="btn sec" href="#/doc/${d.id}">Open</a><button class="btn del" data-act="deldoc" data-id="${d.id}">Delete</button></div></div>`).join('') : '<p>No documents yet. Upload your first form above.</p>'}</div></main>`;
  const drop = $('#drop'), file = $('#file');
  const send = async f => {
    if (!f || busy) return; busy = true; drop.innerHTML = '<b><span class="spin"></span>Reading your form…</b>Scanned images use OCR and can take up to a minute.';
    const fd = new FormData(); fd.append('file', f);
    try { const d = await api('/docs', { method: 'POST', body: fd }); busy = false; go('#/doc/' + d.id); } catch (e) { busy = false; toast(e.message); dashboard(); }
  };
  drop.onclick = () => file.click(); drop.onkeydown = e => { if (e.key === 'Enter' || e.key === ' ') file.click(); };
  file.onchange = () => send(file.files[0]);
  drop.ondragover = e => { e.preventDefault(); drop.classList.add('on'); }; drop.ondragleave = () => drop.classList.remove('on');
  drop.ondrop = e => { e.preventDefault(); send(e.dataTransfer.files[0]); };
}

async function profile() {
  const p = await api('/profile');
  root.innerHTML = head('p') + `<main class="w page"><h1>Your profile</h1><p class="sub">Saved once, reused on every form. Only add what you are comfortable storing. FormPilot never fills a field with something that is not here.</p>
<form class="card" data-form="profile"><div class="two">${PF.map(([k, l]) => `<div style="${LONG.includes(k) ? 'grid-column:1/-1' : ''}"><label for="p_${k}">${l}</label>${LONG.includes(k) ? `<textarea id="p_${k}" maxlength="2000">${esc(p[k])}</textarea>` : `<input type="text" id="p_${k}" maxlength="2000" value="${esc(p[k])}">`}</div>`).join('')}</div>
<div class="acts" style="margin-top:14px"><button class="btn">Save profile</button></div></form>
<div class="card" style="margin-top:20px"><h3>Delete account</h3><p>Permanently deletes your profile, all uploaded files and all answers.</p><button class="btn del" data-act="delacct">Delete my account and data</button></div></main>`;
}

let doc = null;
const fieldHtml = f => `<div class="fld ${f.answer ? '' : 'miss'}" data-fid="${f.id}"><div class="top"><label for="a_${f.id}">${esc(f.label)}</label><span class="chip ${f.status}">${{filled:'From profile',draft:'AI draft: check',edited:'Edited',missing:'Missing'}[f.status]}</span></div>${f.help ? `<p class="h">${esc(f.help)}</p>` : ''}<textarea id="a_${f.id}" maxlength="5000" rows="${f.answer.length > 90 ? 4 : 1}" style="min-height:44px">${esc(f.answer)}</textarea></div>`;
async function docView(id) {
  root.innerHTML = head('d') + '<main class="w page"><p><span class="spin"></span>Loading…</p></main>';
  doc = await api('/docs/' + id);
  const miss = doc.fields.filter(f => !f.answer).length;
  root.innerHTML = head('d') + `<main class="w page"><a href="#/dashboard">← All forms</a><h1 style="margin-top:8px;word-break:break-all">${esc(doc.name)}</h1>
<p class="sub">${doc.fields.length} fields found. <span id="mc">${miss} still need an answer.</span> ${doc.aiUsed ? '' : 'Free mode finds fields by pattern, so check that nothing is missing or extra.'}</p>
<div class="acts" style="margin-bottom:18px"><button class="btn" data-act="autofill">Fill from my profile</button><button class="btn sec" data-act="save">Save draft</button></div>
<div id="fields">${doc.fields.map(fieldHtml).join('')}</div>
<div class="bar"><div class="warn" style="margin-bottom:12px">Legal, immigration, tax, government and financial forms need your careful review. FormPilot can make mistakes and does not give professional advice.</div>
<label class="chk"><input type="checkbox" id="ok"> <span>I reviewed every answer and I confirm it is correct and complete.</span></label>
<button class="btn lg" data-act="export" disabled id="dl">Download ${doc.mime === 'application/pdf' && doc.fields.some(f => f.pdfName) ? 'filled PDF' : 'answer sheet (PDF)'}</button></div></main>`;
  $('#ok').onchange = e => { $('#dl').disabled = !e.target.checked; };
}
const collect = () => doc.fields.map(f => ({ id: f.id, answer: ($('#a_' + f.id) || {}).value ?? f.answer }));

const acts = {
  logout: async () => { await api('/logout', { method: 'POST' }); user = null; go('#/'); },
  deldoc: async a => { if (confirm('Delete this document and its answers permanently?')) { await api('/docs/' + a.dataset.id, { method: 'DELETE' }); toast('Document deleted.'); dashboard(); } },
  delacct: async () => { if (confirm('This permanently deletes your account, profile and all files. Continue?')) { await api('/me', { method: 'DELETE' }); user = null; toast('Account deleted.'); go('#/'); } },
  save: async () => { doc = await api('/docs/' + doc.id, { method: 'PUT', body: { fields: collect() } }); toast('Draft saved.'); },
  autofill: async a => {
    a.disabled = true; a.innerHTML = '<span class="spin"></span>Filling…';
    try { await api('/docs/' + doc.id, { method: 'PUT', body: { fields: collect() } }); doc = await api('/docs/' + doc.id + '/autofill', { method: 'POST' }); $('#fields').innerHTML = doc.fields.map(fieldHtml).join(''); const m = doc.fields.filter(f => !f.answer).length; $('#mc').textContent = m + ' still need an answer.'; toast(m ? 'Done. Fill in the highlighted fields yourself.' : 'All fields have an answer. Please review them.'); }
    catch (e) { toast(e.message); }
    a.disabled = false; a.textContent = 'Fill from my profile';
  },
  export: async a => {
    a.disabled = true; a.innerHTML = '<span class="spin"></span>Preparing…';
    try {
      await api('/docs/' + doc.id, { method: 'PUT', body: { fields: collect() } });
      const r = await api('/docs/' + doc.id + '/export', { method: 'POST', body: { confirmed: true } });
      const url = URL.createObjectURL(await r.blob()), l = document.createElement('a');
      l.href = url; l.download = doc.name.replace(/\.[^.]+$/, '') + (r.headers.get('x-filled-original') === '1' ? '-filled.pdf' : '-answers.pdf'); l.click(); setTimeout(() => URL.revokeObjectURL(url), 5e3);
      toast(r.headers.get('x-filled-original') === '1' ? 'Filled PDF downloaded.' : 'Answer sheet downloaded. Copy these answers onto your original form.');
    } catch (e) { toast(e.message); }
    a.disabled = false; a.textContent = 'Download again';
  }
};
document.addEventListener('click', e => { const a = e.target.closest('[data-act]'); if (a) acts[a.dataset.act](a).catch?.(x => toast(x.message)); });
document.addEventListener('submit', async e => {
  const f = e.target.dataset.form; if (!f) return; e.preventDefault();
  try {
    if (f === 'auth') { const isNew = e.target.dataset.new === '1'; const r = await api(isNew ? '/register' : '/login', { method: 'POST', body: { email: $('#em').value, password: $('#pw').value } }); user = r; go('#/dashboard'); }
    if (f === 'profile') { const b = {}; PF.forEach(([k]) => b[k] = $('#p_' + k).value); await api('/profile', { method: 'PUT', body: b }); toast('Profile saved.'); }
  } catch (x) { const el = $('#err'); if (el) el.textContent = x.message; else toast(x.message); }
});

async function route() {
  const [path, q] = location.hash.slice(1).split('?'); const p = path || '/';
  window.scrollTo(0, 0);
  try {
    if (!user) { try { user = await api('/me'); } catch (e) { user = null; } }
    if (p === '/') return landing();
    if (p === '/login') return user ? go('#/dashboard') : authView(q === 'new');
    if (!user) return go('#/login');
    if (p === '/dashboard') return dashboard();
    if (p === '/profile') return profile();
    if (p.startsWith('/doc/')) return docView(p.slice(5));
    go('#/');
  } catch (e) { toast(e.message); }
}
window.addEventListener('hashchange', route);
fetch('/api/status').then(r => r.json()).then(s => { ai = s.ai; }).catch(() => {}).then(route);
})();
